users
alice|password123|482c811da5d5b4bc6d497ffa98491e38
bob|qwerty|d8578edf8458ce06fbc5bb76a58c5ca4
admin|admin|21232f297a57a5a743894a0e4a801fc3

accounts
ACC-1001|alice|4200.00
ACC-1002|bob|12800.00
